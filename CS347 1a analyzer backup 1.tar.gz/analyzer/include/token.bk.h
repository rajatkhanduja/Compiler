#include "stable.h"

struct token
{
	char* name;
	struct stable_entry *attr;
};
